
/*
 Este programa muestra un mensaje por pantalla, y me ha servido
 para ejemplificar el uso del entorno de desarrollo Eclipse.
 */
public class HolaMundo {

	public static void main(String[] args) {
		
		//Instrucci�n que muestra por pantalla un mensaje
		System.out.println("Hola mundo Lenguaje Java");


	}

}
