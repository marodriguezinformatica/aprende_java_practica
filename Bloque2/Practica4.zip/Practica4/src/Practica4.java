import java.util.Scanner;

public class Practica4 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Introzca la base del tri�ngulo: ");
		double base = sc.nextDouble();
		System.out.println("Introduzca la altura del tri�ngulo: ");
		double altura = sc.nextDouble();
		
		//double area = (base * altura)/2;
		
		System.out.println("El area del tri�ngulo de base " + base 
				+ " y altura " + altura + " es: " + (base * altura)/2);

	}

}
