import java.util.Scanner;

public class Practica5 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		int op1,op2;
		System.out.println("Introduce el primer operando");
		try {
			op1 = sc.nextInt();
		}
		catch(Exception ex) {
			System.out.println("Tipo de dato introducido incorrecto."
					+ "Se asignar� el valor por defecto 1");
			op1 = 1;
		}
		System.out.println("Introduce el segundo operando");
		try {
			op2 = sc.nextInt();
		}
		catch(Exception ex) {
			System.out.println("Tipo de dato introducido incorrecto."
					+ "Se asignar� el valor por defecto 1");
			op2 = 1;
		}
		int suma = op1 + op2;
		System.out.println("Suma: " + suma);
		int resta = op1 - op2;
		System.out.println("Resta: " + resta);
		int multiplicacion = op1 * op2;
		System.out.println("Multiplicaci�n: " + multiplicacion);
		int division;
		try {
			division = op1/op2;
			System.out.println("Divisi�n: " + division);
		}
		catch(Exception ex) {
			System.out.println("No se puede realizar la operaci�n. Divisi�n entre 0");
		}
		
	}

}
