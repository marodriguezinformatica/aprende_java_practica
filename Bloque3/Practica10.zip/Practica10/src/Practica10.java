
public class Practica10 {

	public static void main(String[] args) {
		/*Escribir un programa que muestre por pantalla 
		 * todos los m�ltiplos de 5 entre 1 y 100.
		 */
		/*for (int i=5;i<=100;i=i+5) {
			System.out.println(i);
		}*/
		
		for (int i=1; i<=100; i++) {
			if (i%5 == 0) {
				System.out.println(i);
			}
		}


	}

}
