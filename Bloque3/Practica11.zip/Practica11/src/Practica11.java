import java.util.Scanner;

public class Practica11 {

	public static void main(String[] args) {
		/*Desarrolla un programa que solicite al usuario que introduzca el n�mero 
		 * de alumnos de una clase. A continuaci�n, haciendo uso de un bucle, 
		 * pedir la altura de cada uno de los alumnos.El programa debe mostrar:
			N�mero de alumnos con altura mayor a 1,80.
			N�mero de alumnos con altura menor a 1,80.
			El promedio de alturas de la clase.*/
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce n�mero de alumnos de la clase");
		int num = sc.nextInt();
		int contMayores = 0;
		int contMenores = 0;
		double suma = 0;
		for (int i=1; i<=num; i++) {
			System.out.println("Introduce la altura del alumno " + i);
			double altura = sc.nextDouble();
			suma = suma + altura;
			if (altura >= 1.8) {
				contMayores++;
			}
			else {
				contMenores++;
			}
		}
		double promedio = suma / num;
		System.out.println("N�mero de alumnos con altura mayor a 1.80: " + contMayores);
		System.out.println("N�mero de alumnos con altura menor a 1.80: " + contMenores);
		System.out.println("Promedio de alturas: " + promedio);


	}

}
