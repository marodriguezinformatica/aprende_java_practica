import java.util.Scanner;

public class Practica12 {

	public static void main(String[] args) {
		
		/*Escribe un programa que lea n�meros constantemente mientras 
		 * no se introduzca un 0. El programa debe mostrar cuantos de los n�meros 
		 * introducidos son pares y cuantos impares.
		 */
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce un n�mero");
		int numero = sc.nextInt();
		int cont_pares = 0;
		int cont_impares = 0;
		while (numero != 0) {
			if (numero % 2 == 0) {
				cont_pares++;
			}
			else {
				cont_impares++;
			}
			System.out.println("Introduce un n�mero");
			numero = sc.nextInt();
		}
		
		System.out.println("Cantidad de n�meros pares introducidos: " + cont_pares);
		System.out.println("Cantidad de n�meros impares introducidos: " + cont_impares);


	}

}
