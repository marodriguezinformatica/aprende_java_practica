import java.util.Scanner;

public class Practica6 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce un n�mero: ");
		int numero = sc.nextInt();
		
		if (numero < 0 && numero%3 == 0) {
			System.out.println("El n�mero " + numero + " es negativo y m�ltiplo de 3");
		}
		else {
			System.out.println("El n�mero " + numero + " no es negativo y m�ltiplo de 3");
		}

	}

}
