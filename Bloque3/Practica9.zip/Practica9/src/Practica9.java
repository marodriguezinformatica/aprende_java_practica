import java.util.Scanner;

public class Practica9 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce un n�mero correspondiente a un d�a de la semana");
		int dia = sc.nextInt();
		
		switch(dia) {
			case 1:{
				/*System.out.println("Lunes");
				break;*/
			}
			case 2:{
				/*System.out.println("Martes");
				break;*/
			}
			case 3:{
				/*System.out.println("Mi�rcoles");
				break;*/
			}
			case 4:{
				/*System.out.println("Jueves");
				break;*/
			}
			case 5:{
				/*System.out.println("Viernes");
				break;*/
				System.out.println("D�a laborable");
				break;
			}
			case 6:{
				/*System.out.println("S�bado");
				break;*/
			}
			case 7:{
				/*System.out.println("Domingo");
				break;*/
				System.out.println("D�a no laborable");
				break;
			}
			default:{
				System.out.println("D�a incorrecto");
				break;
			}
		}

	}

}
