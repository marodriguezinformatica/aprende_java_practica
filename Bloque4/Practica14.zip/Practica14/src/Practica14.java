import java.util.Scanner;

public class Practica14 {

	public static void main(String[] args) {
		
		/*Cargar una cadena por teclado. Mostrar a continuaci�n por pantalla 
		 * cuantos espacios en blanco se ingresaron.
		 */
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce una cadena");
		String cadena = sc.nextLine();
		int contador_espacios = 0;
		
		for (int i=0; i<cadena.length(); i++) {
			if (cadena.charAt(i) == ' ') {
				contador_espacios++;
			}
		}
		
		System.out.println("El n�mero de espacios en blanco de la cadena es: " + contador_espacios);

	}

}
