import java.util.Scanner;

public class Practica15 {

	public static void main(String[] args) {
		/*Desarrollar un programa que valide contrase�as. 
		 * Una contrase�a ser� v�lida cuando tenga entre 10 y 20 caracteres 
		 * y contenga alguno de los 3 siguientes caracteres: *,-,_. 
		 * En caso de que la contrase�a no sea v�lida, mostrar mensaje de error.
		 */
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce la contrase�a a validar");
		String pass = sc.nextLine();
		
		if (pass.length() >= 10 && pass.length() <= 20) {
			
			boolean valida = false;
			
			for (int i=0; i<pass.length(); i++) {
				
				if (pass.charAt(i) == '*' || pass.charAt(i) == '-' 
						|| pass.charAt(i) == '_') {
					valida = true;
				}
			}
			
			if (valida) {
				System.out.println("La contrase�a es valida");
			}
			else {
				System.out.println("La contrase�a no tiene los caracteres necesarios");
			}
		}
		else {
			System.out.println("La contrase�a no tiene la longitud correcta");
		}

	}

}
