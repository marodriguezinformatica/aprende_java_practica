import java.util.Scanner;

public class Practica16 {

	public static void main(String[] args) {
		
		/*Dada una cadena introducida por teclado, comprobar si es pal�ndroma, 
		 * es decir, si se lee igual por el principio que por el final.
		 * Ejemplo: radar 
		 */
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce una cadena");
		String cadena = sc.nextLine();
		String cadena2 = "";
		
		for (int i=cadena.length()-1; i>=0; i--) {
			char c = cadena.charAt(i);
			cadena2 = cadena2 + c;
		}
		
		if (cadena.equals(cadena2)) {
			System.out.println("La cadena :" + cadena + " es pal�ndroma");
		}
		else {
			System.out.println("La cadena: " + cadena + " no es pal�ndroma");
		}
	}

}
