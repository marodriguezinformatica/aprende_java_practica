import java.util.Scanner;

public class Practica18 {

	public static void main(String[] args) {
		
		 /* Pedir al usuario la temperatura de los 7 d�as de la semana 
		 * y almacenarlas en un array. Mostrar  la temperatura media e indicar 
		 * si se ha bajado de los 0� alg�n d�a.
		 */
		
		Scanner sc = new Scanner(System.in);
		double[] temperaturas = new double[7];
		
		//Inicializar array
		for(int i=0;i<7;i++) {
			System.out.println("Introduce la temperatura del d�a " + (i+1) + " de la semana");
			temperaturas[i] = sc.nextDouble();
		}
		double suma = 0;
		boolean resultado = false;
		//Calcular datos
		for(int i=0; i<7; i++) {
			suma = suma + temperaturas[i];
			if (temperaturas[i]<0) {
				resultado = true;
			}
		}
		double media = suma/7;
		System.out.println("La temperatura media de la semana es : " + media);
		
		if (resultado) {
			System.out.println("Ha habido alg�n d�a por debajo de 0�");
		}
		else {
			System.out.println("No ha habido ning�n dia por debajo de 0�");
		}
		
		
		

	}

}
