
public class Practica19 {

	public static void main(String[] args) {
		/*La informaci�n acad�mica de los alumnos de una determinada asignatura se encuentra almacenada en una matriz. 
		 * Cada fila de la matriz guarda las notas de un alumno. La primera posici�n 
		 * indica el nombre del alumno, las dos siguientes la nota de los ex�menes de 
		 * teor�a y el siguiente la nota del examen de pr�cticas. La nota final se 
		 * calcula de la siguiente forma: NF = 40% Teor�a + 60% Pr�ctica
		 *Realiza un programa en el que definas una matriz como la anterior y
		 *muestre para cada alumno si ha aprobado o suspendido la asignatura.*/

		String[][] informacion = {{"pepe","6.5","7.5","8"},{"ana","5","6.5","7"},{"juan","3.5","4.5","4"}};
		boolean[] resultados = new boolean[informacion.length];
		for (int i=0; i<informacion.length; i++) {
			for(int j=0; j<informacion[i].length; j++) {
				double notaTeoria = (Double.parseDouble(informacion[i][1]) + Double.parseDouble(informacion[i][2]))/2;
				double notaFinal = notaTeoria*0.4 + Double.parseDouble(informacion[i][3])*0.6;
				if (notaFinal >= 5) {
					resultados[i] = true;
				}
				else {
					resultados[i] = false;
				}
			}
		}
		for (int i=0; i< resultados.length; i++) {
			if (resultados[i]) {
				System.out.println("El alumno " + informacion[i][0] + " ha aprobado");
			}
			else {
				System.out.println("El alumno " + informacion[i][0] + " no ha aprobado");
			}
		}
	}

}
