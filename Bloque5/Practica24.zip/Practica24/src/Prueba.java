
public class Prueba {

	public static void main(String[] args) {
		
		Senador s1 = new Senador();
		System.out.println(s1);
		Senador s2 = new Senador("pepe","rodriguez",28,false,"sevilla","partido 1",1);
		System.out.println(s2);
		Diputado d1 = new Diputado();
		System.out.println(d1);
		Diputado d2 = new Diputado("raul","sanchez",40,true,"c�diz","partido 2",2);
		System.out.println(d2);
		Legislador[] legisladores = {s1,s2,d1,d2};
		
		for (int i=0; i<legisladores.length; i++) {
			System.out.println(legisladores[i].getCamaraEnQueTrabaja());
		}

	}

}
