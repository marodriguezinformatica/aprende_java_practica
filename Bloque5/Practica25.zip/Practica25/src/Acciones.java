
public interface Acciones {

	public void cantar();
	public void andar();
}
