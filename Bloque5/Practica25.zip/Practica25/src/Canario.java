
public class Canario implements Acciones{

	@Override
	public void cantar() {
		System.out.println("pio pio pio pio");
		
	}

	@Override
	public void andar() {
		System.out.println("Puedo andar, pero me gusta m�s volar");
		
	}

}
