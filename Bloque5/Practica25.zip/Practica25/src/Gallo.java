
public class Gallo implements Acciones{

	@Override
	public void cantar() {
		System.out.println("ki ki ri kiiiii");
		
	}

	@Override
	public void andar() {
		System.out.println("Ando a 2 patas");
		
	}

}
