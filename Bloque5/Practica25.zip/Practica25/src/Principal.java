
public class Principal {

	public static void main(String[] args) {
		Persona p = new Persona();
		Gallo g = new Gallo();
		Canario c = new Canario();
		p.andar();
		p.cantar();
		g.andar();
		g.cantar();
		c.andar();
		c.cantar();

	}

}
