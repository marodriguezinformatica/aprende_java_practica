
public class PruebaAlmacen {

	public static void main(String[] args) {
		
		AguaMineral b1 = new AguaMineral(1,1,"marca1",0.75,"manantial");
		AguaMineral b2 = new AguaMineral(2,1.5,"marca2",0.9,"manantial");
		BebidaAzucarada b3 = new BebidaAzucarada(3,1.5,"marca3",1.5,20);
		BebidaAzucarada b4 = new BebidaAzucarada(4,0.5,"marca3",0.5,20);
		
		Almacen almacen = new Almacen();
		almacen.agregarBebida(b1);
		almacen.agregarBebida(b2);
		almacen.agregarBebida(b3);
		almacen.agregarBebida(b4);
		almacen.eliminarBebida(b2);
		System.out.println(almacen.precioTotalMarca("marca3"));
		System.out.println(almacen.precioTotal());
		almacen.mostrarInformacion();

	}

}
