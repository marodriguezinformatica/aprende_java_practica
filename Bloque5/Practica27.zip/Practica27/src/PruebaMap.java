import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class PruebaMap {

	public static void main(String[] args) {
		
		Map<String,Integer> alumnos = new HashMap<String,Integer>();
		Scanner sc = new Scanner(System.in);
		
		int opcion = -1;
		
		while (opcion != 2) {
			System.out.println("Introduce la opci�n que deseas: ");
			System.out.println("1- Introducir asignatura y cr�ditos");
			System.out.println("2- Salir");
			opcion = sc.nextInt();
			sc.nextLine();
			if (opcion == 1) {
				System.out.println("Introduce el nombre de la asignatura");
				String asignatura = sc.nextLine();
				System.out.println("Introduce los cr�ditos de la asignatura");
				int creditos = sc.nextInt();
				alumnos.put(asignatura, creditos);
			}
		}
		
		int totalCreditos = 0;
		
		for (String asig: alumnos.keySet()) {
			totalCreditos += alumnos.get(asig);
		}
		
		System.out.println("El n�mero de cr�ditos que est�s cursando es: " + totalCreditos);
		
		

	}

}
