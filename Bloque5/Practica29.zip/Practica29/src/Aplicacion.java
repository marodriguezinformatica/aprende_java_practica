import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Aplicacion extends JFrame {

	private JPanel contentPane;
	private JTextField txtAleatorio;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Aplicacion frame = new Aplicacion();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Aplicacion() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 525, 327);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblTitulo = new JLabel("Generador de n\u00FAmeros aleatorios");
		lblTitulo.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblTitulo.setBounds(138, 10, 227, 34);
		contentPane.add(lblTitulo);
		
		JSpinner spMin = new JSpinner();
		spMin.setBounds(266, 73, 119, 20);
		contentPane.add(spMin);
		
		JSpinner spMax = new JSpinner();
		spMax.setBounds(266, 122, 119, 20);
		contentPane.add(spMax);
		
		JLabel lblMin = new JLabel("Min");
		lblMin.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblMin.setBounds(173, 75, 45, 13);
		contentPane.add(lblMin);
		
		JLabel lblMax = new JLabel("Max");
		lblMax.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblMax.setBounds(173, 125, 45, 13);
		contentPane.add(lblMax);
		
		txtAleatorio = new JTextField();
		txtAleatorio.setBounds(266, 201, 103, 19);
		contentPane.add(txtAleatorio);
		txtAleatorio.setColumns(10);
		
		JLabel lblAleatorio = new JLabel("Aleatorio");
		lblAleatorio.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblAleatorio.setBounds(173, 204, 61, 16);
		contentPane.add(lblAleatorio);
		
		JButton btnAleatorio = new JButton("Generar");
		btnAleatorio.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int min = (int)spMin.getValue();
				int max = (int)spMax.getValue();
				
				int aleatorio = (int)Math.floor(Math.random()*(max-min+1));
				
				txtAleatorio.setText(String.valueOf(aleatorio));
			}
		});
		btnAleatorio.setBackground(Color.CYAN);
		btnAleatorio.setForeground(Color.RED);
		btnAleatorio.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnAleatorio.setBounds(41, 200, 85, 21);
		contentPane.add(btnAleatorio);
	}
}
