import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Aplicacion {

	private static int indice = 0;
	private static List<Coche> coches = new ArrayList<Coche>();
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		cargarCoches();
		mostrarCoche();
		mostrarMenu();
		
		int op = sc.nextInt();
		
		while (op != 3) {
			
			if (op == 1) {
				
				if (indice == coches.size() - 1) {
					indice = 0;
				}
				else {
					indice++;
				}
				mostrarCoche();
			}
			else if(op == 2) {
				
				if (indice == 0) {
					indice = coches.size() - 1;
				}
				else {
					indice --;
				}
				mostrarCoche();
			}
			mostrarMenu();
			op = sc.nextInt();
			
		}
		
		sc.close();
		

	}
	
	public static void cargarCoches() {
		
		DBConnection con = new DBConnection();
		String sql = "SELECT * FROM COCHES";
		
		try {
			Statement st = con.getConnection().createStatement();
			ResultSet rs = st.executeQuery(sql);
			
			while (rs.next()) {
				String matricula = rs.getString("matricula");
				String marca = rs.getString("marca");
				String modelo = rs.getString("modelo");
				String color = rs.getString("color");
				int anio = rs.getInt("anio");
				int precio = rs.getInt("precio");
				
				Coche c = new Coche(matricula,marca,modelo,color,anio,precio);
				coches.add(c);
			}
			
		}
		catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
		con.desconectar();
		
		
	}
	
	public static void mostrarCoche() {
		
		System.out.println(coches.get(indice).toString());
	}
	
	public static void mostrarMenu() {
		System.out.println("1-Siguiente");
		System.out.println("2-Antorior");
		System.out.println("3-Salir");
		
		System.out.println("Elige una opci�n");
	}

}
